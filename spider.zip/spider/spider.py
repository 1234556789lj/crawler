# -*- coding: utf-8 -*
import time
import random
import requests
from lxml import html
from fake_useragent import UserAgent
import csv
import re

def get_info(page):
    # 随机头信息
    headers = {
        'User-Agent': UserAgent().random
    }
    url = 'https://gy.fang.lianjia.com/loupan/pg' + page
    try:
        requests.packages.urllib3.disable_warnings()
        res = requests.get(url, headers=headers, verify=False)
        context = html.etree.HTML(res.text)
        #print(context)
        with open('data.csv', 'a', newline='', encoding='utf-8-sig') as csvfile:
            fieldnames = ['辖区', '楼盘名称', '位置', '详细地址', '类型', '楼盘状态', '最小面积','最大面积', '均价', '最低总价','最高总价', '标签1', '标签2', '标签3', '标签4']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            # 检查文件是否为空，为空就写入标题
            if csvfile.tell() == 0:
                writer.writeheader()

            ul = context.xpath('//ul[@class="resblock-list-wrapper"]')  # 获取标签,按页遍历
            for i in ul:# 遍历每一个ul[@class="resblock-list-wrapper"下的每一个li标签
                li = i.xpath('.//li[@class="resblock-list post_ulog_exposure_scroll has-results"]')
                for j in li:
                    try:
                        con= j.xpath('.//div[@class="resblock-desc-wrapper"]')
                        for a in con:#遍历con
                            area = a.xpath(".//div[@class='resblock-location']/span[1]/text()")
                            print("辖区：",area[0])
                            name =a.xpath(".//div[@class='resblock-name']/a/text()")
                            print("楼盘名称：",name[0])
                            area_b =a.xpath(".//div[@class='resblock-location']/span[2]/text()")
                            print("位置：",area_b[0])
                            area_code = a.xpath(".//div[@class='resblock-location']/a/text()")#
                            print("详细地址：",area_code[0])
                            type = a.xpath(".//div[@class='resblock-name']/span[1]/text()")
                            print("类型：",type[0])
                            stat = a.xpath(".//div[@class='resblock-name']/span[2]/text()")
                            print("房子状态：",stat[0])
                            square = a.xpath('.//div[@class="resblock-area"]//span//text()')
                            #正则提取数字
                            square = re.findall(r'\d+', square[0])
                            print("面积：", square)
                            avg_price=a.xpath('.//div[@class="resblock-price"]//div[@class="main-price"]//span//text()')
                            print("均价：",avg_price[0],"元/㎡")
                            price = a.xpath('.//div[@class="resblock-price"]//div[@class="second"]//text()')
                            # 正则提取数字
                            price=re.findall(r'\d+', price[0])
                            print("总价：", price,"万/套")
                            #遍历楼盘标签
                            tag=[]
                            for i in range(5):
                                tag.append(a.xpath(f'.//div[@class="resblock-tag"]/span[{i}]/text()')[0] if a.xpath(f'.//div[@class="resblock-tag"]/span[{i}]/text()') else '')
                            #写入csv文件
                            writer.writerow({
                                '辖区': area[0],
                                '楼盘名称': name[0],
                                '位置': area_b[0],
                                '详细地址': area_code[0],
                                '类型': type[0],
                                '楼盘状态': stat[0],
                                '最小面积': square[0],
                                '最大面积':square[1],
                                '均价': avg_price[0],
                                '最低总价': price[0],
                                '最高总价':price[1],
                                '标签1': tag[1],
                                '标签2': tag[2],
                                '标签3': tag[3],
                                '标签4': tag[4],
                            })
                            time.sleep(random.randint(1, 5))
                    except Exception as e:
                        print('提取信息发生错误',e)
                        # 遍历楼盘标签
                        tag = []
                        for i in range(5):
                            tag.append(a.xpath(f'.//div[@class="resblock-tag"]/span[{i}]/text()')[0] if a.xpath(f'.//div[@class="resblock-tag"]/span[{i}]/text()') else '')
                        # 写入csv文件
                        writer.writerow({
                            '辖区': area[0],
                            '楼盘名称': name[0],
                            '位置': area_b[0] if area_b else area[0],
                            '详细地址': area_code[0],
                            '类型': type[0],
                            '楼盘状态': stat[0],
                            '最小面积': 0,
                            '最大面积': 0,
                            '均价': 0,
                            '最低总价': 0,
                            '最高总价': 0,
                            '标签1': tag[1],
                            '标签2': tag[2],
                            '标签3': tag[3],
                            '标签4': tag[4],
                        })
                        time.sleep(random.randint(1, 5))

            sleeptime = random.randint(30, 35)
            print("睡眠%d秒后继续" %sleeptime)
            time.sleep(sleeptime)
    except requests.exceptions as e:
        print("发送数据包发生错误",e)

if __name__ == '__main__':
    # 遍历的页数
    for i in range(11, 19):
        print("正在爬取第%d页" % i)
        get_info(str(i))
        print("任务完成")
    print("爬完")

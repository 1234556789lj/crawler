import pandas as pd
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['SimHei']  # 设置中文显示

# 读取CSV文件
df = pd.read_csv('data.csv')


# 统计每个辖区的数量
area_counts = df['辖区'].value_counts()
threshold = 0.03  # 设置一个占比的阈值
small_parts = area_counts[area_counts / area_counts.sum() < threshold]
area_counts['其他'] = small_parts.sum()
area_counts = area_counts[area_counts / area_counts.sum() >= threshold]
# 创建扇形图
plt.figure(figsize=(10, 10))
plt.pie(area_counts, labels=area_counts.index, autopct='%1.1f%%', startangle=90, labeldistance=1.1, textprops={'rotation': 'horizontal'})
plt.title('各辖区占比')
plt.show()

# 统计每种类型的数量
type_counts = df['类型'].value_counts()
# 创建扇形图
plt.figure(figsize=(12, 12))
plt.pie(type_counts, labels=type_counts.index, autopct='%1.1f%%', startangle=90, labeldistance=1.2, textprops={'rotation': 'horizontal'})
plt.title('各类型楼盘占比')
plt.show()


# 将均价数据转换为数值类型
df['均价'] = pd.to_numeric(df['均价'], errors='coerce')
# 过滤掉均价为0的数据
df = df[df['均价'] > 0]
# 按辖区分组，计算均价的总和和平均值
average_prices = df.groupby('辖区')['均价'].agg(['sum', 'mean'])
# 按平均值排序
sorted_avg_prices = average_prices.sort_values(by='mean', ascending=False)
# 可视化输出
plt.figure(figsize=(12, 8))
sorted_avg_prices['mean'].plot(kind='bar', color='skyblue')
plt.title('各辖区均价排序')
plt.xlabel('辖区')
plt.ylabel('均价')
plt.xticks(rotation=45, ha='right')  # 使x轴标签斜着显示
plt.show()

# 读取CSV文件
df = pd.read_csv('data.csv')

# 获取唯一的辖区列表
unique_areas = df['辖区'].unique()

# 遍历每个辖区，绘制独立的可视化图
for area in unique_areas:
    # 筛选出当前辖区的数据
    area_data = df[df['辖区'] == area]

    # 将标签列转换为长格式
    area_tags = area_data[['辖区', '标签1', '标签2', '标签3', '标签4']]
    area_tags_melted = area_tags.melt(id_vars=['辖区'], value_vars=['标签1', '标签2', '标签3', '标签4'],value_name='标签').dropna()

    # 统计当前辖区中标签的数量
    tag_counts = area_tags_melted.groupby(['辖区', '标签']).size().unstack().fillna(0)

    # 可视化输出
    plt.figure(figsize=(10, 8))
    tag_counts.plot(kind='bar', stacked=True, colormap='viridis')
    plt.title(f'{area}辖区标签数量统计')
    plt.xlabel('标签')
    plt.ylabel('数量')
    plt.xticks(rotation=45, ha='right')  # 使x轴标签斜着显示
    plt.legend(title='标签')
    plt.show()
